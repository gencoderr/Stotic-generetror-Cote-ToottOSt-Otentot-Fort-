autoreconf -i
automake --add-missing --copy &>/dev/null
