
import React from 'react';
import { TransformationType } from '../types';

interface ControlsProps {
  onTransform: (type: TransformationType) => void;
  isLoading: boolean;
}

const ControlButton: React.FC<{
  onClick: () => void;
  disabled: boolean;
  children: React.ReactNode;
  className?: string;
}> = ({ onClick, disabled, children, className = '' }) => (
  <button
    onClick={onClick}
    disabled={disabled}
    className={`w-full px-4 py-3 font-semibold rounded-lg shadow-md transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 disabled:opacity-50 disabled:cursor-not-allowed ${className}`}
  >
    {children}
  </button>
);

const Controls: React.FC<ControlsProps> = ({ onTransform, isLoading }) => {
  const transformationTypes = Object.values(TransformationType);

  return (
    <div className="bg-gray-800/50 p-4 rounded-xl border border-gray-700">
        <h2 className="text-xl font-semibold mb-4 text-center text-teal-300">Choose a Processor</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {transformationTypes.map((type) => (
                <ControlButton
                    key={type}
                    onClick={() => onTransform(type)}
                    disabled={isLoading}
                    className="bg-gray-700 text-gray-200 hover:bg-teal-600 focus:ring-teal-500"
                >
                    {type}
                </ControlButton>
            ))}
        </div>
    </div>
  );
};

export default Controls;
