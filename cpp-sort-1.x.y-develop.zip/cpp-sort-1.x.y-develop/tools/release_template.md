TODO: description of the new version

### Deprecations

TODO

Deprecated components will be removed in cpp-sort 2.0.0.

Deprecation warnings can be disabled by defining the preprocessor macro [`CPPSORT_DISABLE_DEPRECATION_WARNINGS`][deprecation-warnings].

### New features

TODO 1

TODO 2

### Improvements

Algorithmic & speed improvements:
* TODO

Other improvements:
* TODO

### Tooling

Documentation:
* TODO

Benchmarks:
* TODO

Test suite:
* TODO

Miscellaneous:
* TODO

### Known bugs

I didn't manage to fix every bug I could find since the previous release, so you might want to check the [list of known bugs][known-bugs].


  [deprecation-warnings]: https://github.com/Morwenn/cpp-sort/wiki#deprecation-warnings
  [known-bugs]: https://github.com/Morwenn/cpp-sort/issues?q=is%3Aissue+is%3Aopen+label%3Abug
