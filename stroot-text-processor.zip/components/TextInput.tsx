
import React from 'react';

interface TextInputProps {
  value: string;
  onChange: (event: React.ChangeEvent<HTMLTextAreaElement>) => void;
  placeholder: string;
  disabled: boolean;
}

const TextInput: React.FC<TextInputProps> = ({ value, onChange, placeholder, disabled }) => {
  return (
    <textarea
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      disabled={disabled}
      className="w-full flex-grow bg-gray-900/50 border-2 border-gray-700 rounded-xl p-4 text-gray-200 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-colors duration-300 resize-none disabled:opacity-60 text-base min-h-[300px] lg:min-h-0"
      rows={15}
    />
  );
};

export default TextInput;
