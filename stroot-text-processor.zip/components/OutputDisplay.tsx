import React, { useState, useEffect } from 'react';
import Loader from './Loader';
import { TransformationType } from '../types';

interface OutputDisplayProps {
  text: string;
  isLoading: boolean;
  transformationType: TransformationType | null;
}

const OutputDisplay: React.FC<OutputDisplayProps> = ({ text, isLoading, transformationType }) => {
  const [copyStatus, setCopyStatus] = useState<'idle' | 'copied'>('idle');

  useEffect(() => {
    if (copyStatus === 'copied') {
      const timer = setTimeout(() => setCopyStatus('idle'), 2000);
      return () => clearTimeout(timer);
    }
  }, [copyStatus]);
  
  const handleCopy = () => {
    if (text) {
      navigator.clipboard.writeText(text);
      setCopyStatus('copied');
    }
  };

  const handleDownload = () => {
    if (!text || !transformationType) return;

    const getFileDetails = (): { filename: string; mimeType: string } => {
      switch (transformationType) {
        case TransformationType.TO_JSON:
          return { filename: 'output.json', mimeType: 'application/json' };
        case TransformationType.EXPLAIN_CODE:
          return { filename: 'explanation.md', mimeType: 'text/markdown' };
        case TransformationType.FORMAT_STRUCTURE:
          return { filename: 'formatted_output.md', mimeType: 'text/markdown' };
        case TransformationType.GITHUB_README:
          return { filename: 'README.md', mimeType: 'text/markdown' };
        case TransformationType.CLOUD_CONFIG:
          return { filename: '.env', mimeType: 'text/plain' };
        default:
          return { filename: 'output.txt', mimeType: 'text/plain' };
      }
    };

    const { filename, mimeType } = getFileDetails();
    const blob = new Blob([text], { type: `${mimeType};charset=utf-8` });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="relative flex flex-col w-full h-full bg-gray-900/50 border-2 border-gray-700 rounded-xl p-4">
      {text && !isLoading && (
        <div className="absolute top-3 right-3 flex items-center gap-2">
            <button
                onClick={handleDownload}
                title="Download"
                aria-label="Download output"
                className="bg-gray-700 hover:bg-teal-600 text-white p-2 rounded-md transition-colors duration-200"
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
            </button>
            <button
                onClick={handleCopy}
                className="bg-gray-700 hover:bg-teal-600 text-white font-semibold py-2 px-3 rounded-md transition-colors duration-200 text-sm"
            >
                {copyStatus === 'idle' ? 'Copy' : 'Copied!'}
            </button>
        </div>
      )}
      <div className="flex-grow overflow-y-auto pr-2">
        {isLoading ? (
          <div className="flex items-center justify-center h-full">
            <Loader />
          </div>
        ) : text ? (
          <pre className="whitespace-pre-wrap text-gray-300 text-base leading-relaxed font-sans">{text}</pre>
        ) : (
          <div className="flex items-center justify-center h-full text-gray-500">
            Your processed output will appear here...
          </div>
        )}
      </div>
    </div>
  );
};

export default OutputDisplay;