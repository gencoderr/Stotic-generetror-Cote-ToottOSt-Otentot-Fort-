export enum TransformationType {
  SUMMARIZE = 'Summarize',
  TRANSLATE_PIRATE = 'Translate to Pirate',
  TO_JSON = 'Convert to JSON',
  EXPLAIN_CODE = 'Explain Code',
  REWRITE_FORMAL = 'Rewrite Formally',
  FORMAT_STRUCTURE = 'Format & Structure',
  GITHUB_README = 'GitHub Readme',
  CLOUD_CONFIG = 'Cloud Config',
}