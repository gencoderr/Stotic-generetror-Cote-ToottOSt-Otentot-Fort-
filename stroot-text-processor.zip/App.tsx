
import React, { useState, useCallback } from 'react';
import { TransformationType } from './types';
import { processText } from './services/geminiService';
import Header from './components/Header';
import Controls from './components/Controls';
import TextInput from './components/TextInput';
import OutputDisplay from './components/OutputDisplay';

const App: React.FC = () => {
  const [inputText, setInputText] = useState<string>('');
  const [outputText, setOutputText] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [lastTransformation, setLastTransformation] = useState<TransformationType | null>(null);

  const handleTransform = useCallback(async (type: TransformationType) => {
    if (!inputText.trim()) {
      setError('Input text cannot be empty.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setOutputText('');
    setLastTransformation(null);

    try {
      const result = await processText(inputText, type);
      setOutputText(result);
      setLastTransformation(type);
    } catch (e) {
      const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
      setError(`Failed to process text: ${errorMessage}`);
      setOutputText('');
    } finally {
      setIsLoading(false);
    }
  }, [inputText]);

  return (
    <div className="min-h-screen bg-gray-900 text-gray-200 flex flex-col p-4 sm:p-6 lg:p-8">
      <Header />
      {error && (
        <div className="bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 rounded-lg relative my-4 max-w-4xl mx-auto w-full" role="alert">
          <strong className="font-bold">Error: </strong>
          <span className="block sm:inline">{error}</span>
        </div>
      )}
      <main className="flex-grow grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
        <div className="flex flex-col gap-4">
          <TextInput
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Enter text or code here..."
            disabled={isLoading}
          />
          <Controls onTransform={handleTransform} isLoading={isLoading} />
        </div>
        <div className="flex flex-col">
          <OutputDisplay
            text={outputText}
            isLoading={isLoading}
            transformationType={lastTransformation}
          />
        </div>
      </main>
    </div>
  );
};

export default App;
