import { GoogleGenAI } from "@google/genai";
import { TransformationType } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const getPromptForTransformation = (text: string, type: TransformationType): string => {
  switch (type) {
    case TransformationType.SUMMARIZE:
      return `Summarize the following text concisely:\n\n---\n${text}\n---`;
    case TransformationType.TRANSLATE_PIRATE:
      return `Translate the following text into the spoken dialect of a stereotypical pirate, with plenty of 'Ahoy!', 'Matey', and 'Shiver me timbers!':\n\n---\n${text}\n---`;
    case TransformationType.TO_JSON:
      return `Analyze the structure and content of the following text and convert it into a well-formed JSON object. If the text is unstructured, create a JSON object with a "summary" key containing the text's meaning. The response must only contain the JSON object.\n\n---\n${text}\n---`;
    case TransformationType.EXPLAIN_CODE:
      return `Explain the following code snippet in simple, easy-to-understand terms. Describe its purpose, what each part does, and provide a simple example of its use if applicable. Format the explanation clearly using markdown.\n\n---\n${text}\n---`;
    case TransformationType.REWRITE_FORMAL:
      return `Rewrite the following text using a formal, professional, and sophisticated tone. Ensure the core message remains the same but is communicated with greater clarity and etiquette suitable for a business or academic context.\n\n---\n${text}\n---`;
    case TransformationType.FORMAT_STRUCTURE:
      return `Analyze the following text and reformat it for maximum clarity and structure. Apply markdown formatting where appropriate, such as headings, lists, bold/italic text, and code blocks. If it's code, format it according to standard conventions for the detected language. The goal is to make the content more readable and organized. The response should only contain the formatted text.\n\n---\n${text}\n---`;
    case TransformationType.GITHUB_README:
      return `Generate a comprehensive and professional GitHub README.md file for a project with the following description. The README should be well-structured with sections like a project title, a short description, key features (as a list), installation instructions (in a code block), usage examples (in a code block), and technologies used. Use appropriate GitHub-flavored markdown. The response should only contain the markdown content for the README file.\n\nProject Description:\n---\n${text}\n---`;
    case TransformationType.CLOUD_CONFIG:
      return `Act as a cloud infrastructure expert. Based on the following user request, generate a sample .env file with the necessary environment variables for the described services. Use standard and conventional variable names (e.g., DATABASE_URL, AWS_ACCESS_KEY_ID). Provide clear placeholders for sensitive values like passwords and API keys (e.g., 'your_secret_key_here'). The response must ONLY contain the text content for the .env file, including comments where helpful.\n\nUser Request:\n---\n${text}\n---`;
    default:
      throw new Error("Unknown transformation type");
  }
};

export const processText = async (text: string, type: TransformationType): Promise<string> => {
  const prompt = getPromptForTransformation(text, type);

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        temperature: 0.5,
        topP: 0.95,
      }
    });
    
    return response.text.trim();
  } catch (error) {
    console.error("Gemini API call failed:", error);
    throw new Error("The AI model failed to respond. Please check your API key and network connection.");
  }
};