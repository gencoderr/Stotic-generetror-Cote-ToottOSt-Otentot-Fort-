.. include:: introduction.rst

.. toctree::
   :hidden:
   :maxdepth: 2

   download.rst
   quickstart.rst
   examples.rst
   TSapproximation.rst
   changes.rst
   reference.rst

