.. title:: Table of Contents

###############################
Trotter-Suzuki-MPI User's Guide
###############################


.. toctree::
   :maxdepth: 2

   introduction.rst
   download.rst
   quickstart.rst
   examples.rst
   TSapproximation.rst
   changes.rst
   reference.rst
