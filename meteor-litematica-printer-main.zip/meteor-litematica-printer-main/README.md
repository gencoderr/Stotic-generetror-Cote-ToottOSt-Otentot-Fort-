# Meteor Litematica Printer

Fast printer to litematica made with meteor client

Works best with simple blocks witout rotation or other properties like dirt stone etc.

For 1.21+ use fork of litematica maintaind by [sakura-ryoko](https://github.com/sakura-ryoko)
 - [litematica](https://github.com/sakura-ryoko/litematica)
 - [malilib (needed for litematica to work)](https://github.com/sakura-ryoko/malilib)